<?php

return [

// After App\Http\Controllers
// Default : Backend
'controller_namespace' => 'Backend',

// After App\Http\Requests
// Default : Backend
'request_namespace' => 'Backend',

// After App\Repositories
// Default : Backend
'repository_namespace'=> 'Backend',

// views folder after resources/views
// Default : backend
'views_folder' => 'backend',

];
