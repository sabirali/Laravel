<?php
    use Illuminate\Support\Facades\Route;
?>
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title', app_name()); ?></title>

        <!-- Meta -->
        <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Laravel AdminPanel'); ?>">
        <meta name="author" content="<?php echo $__env->yieldContent('meta_author', 'Sabirali Kharodiya'); ?>">
        <?php echo $__env->yieldContent('meta'); ?>

        <!-- Styles -->
        <?php echo $__env->yieldContent('before-styles'); ?>

        <!-- Check if the language is set to RTL, so apply the RTL layouts -->
        <!-- Otherwise apply the normal LTR layouts -->
        <?php if (session()->has('lang-rtl')): ?>
            <?php echo e(Html::style(getRtlCss(mix('css/frontend.css')))); ?>

        <?php else: ?>
            <?php echo e(Html::style(mix('css/frontend.css'))); ?>

        <?php endif; ?>
        <?php echo Html::style('js/select2/select2.css'); ?>

        <?php echo $__env->yieldContent('after-styles'); ?>

        <!-- Scripts -->
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>
        </script>
        <?php
            if(!empty($google_analytics)){
                echo $google_analytics;
            }
        ?>
    </head>
    <body id="app-layout">
        <div id="app">
            <?php echo $__env->make('includes.partials.logged-in-as', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('frontend.includes.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="container">
                <?php echo $__env->make('includes.partials.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div><!-- container -->
        </div><!--#app-->

        <!-- Scripts -->
        <?php echo $__env->yieldContent('before-scripts'); ?>
        <?php echo Html::script(mix('js/frontend.js')); ?>

        <?php echo $__env->yieldContent('after-scripts'); ?>
        <?php echo e(Html::script('js/jquerysession.js')); ?>

        <?php echo e(Html::script('js/frontend/frontend.js')); ?>

        <?php echo Html::script('js/select2/select2.js'); ?>


        <script type="text/javascript">
            if("<?php echo e(Route::currentRouteName()); ?>" !== "frontend.user.account")
            {
                $.session.clear();
            }
        </script>
        <?php echo $__env->make('includes.partials.ga', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>