<?php $__env->startSection('title', trans('labels.backend.emailtemplates.management')); ?>

<?php $__env->startSection('page-header'); ?>
    <h1><?php echo e(trans('labels.backend.emailtemplates.management')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('labels.backend.emailtemplates.management')); ?></h3>

            <div class="box-tools pull-right">
                <div class="btn-group">
                  <button type="button" class="btn btn-warning btn-flat dropdown-toggle" data-toggle="dropdown">Export
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="#" id="copyButton"><i class="fa fa-clone"></i> Copy</a></li>
                    <li><a href="#" id="csvButton"><i class="fa fa-file-text-o"></i> CSV</a></li>
                    <li><a href="#" id="excelButton"><i class="fa fa-file-excel-o"></i> Excel</a></li>
                    <li><a href="#" id="pdfButton"><i class="fa fa-file-pdf-o"></i> PDF</a></li>
                    <li><a href="#" id="printButton"><i class="fa fa-print"></i> Print</a></li>
                  </ul>
                </div>
            </div>

        </div><!-- /.box-header -->

        <div class="box-body">
            <div class="table-responsive data-table-wrapper">
                <table id="emailtemplates-table" class="table table-condensed table-hover table-bordered">
                    <thead>
                        <tr>
                            <th><?php echo e(trans('labels.backend.emailtemplates.table.title')); ?></th>
                            <th><?php echo e(trans('labels.backend.emailtemplates.table.subject')); ?></th>
                            <th><?php echo e(trans('labels.backend.emailtemplates.table.status')); ?></th>
                            <th><?php echo e(trans('labels.backend.emailtemplates.table.createdat')); ?></th>
                            <th><?php echo e(trans('labels.backend.emailtemplates.table.updatedat')); ?></th>
                            <th><?php echo e(trans('labels.general.actions')); ?></th>
                        </tr>
                    </thead>
                    <thead class="transparent-bg">
                        <tr>
                            <th>
                                <?php echo Form::text('title', null, ["class" => "search-input-text form-control", "data-column" => 0, "placeholder" => trans('labels.backend.emailtemplates.table.title')]); ?>

                                <a class="reset-data" href="javascript:void(0)" data-column=0><i class="fa fa-times"></i></a>
                            </th>
                            <th>
                                <?php echo Form::text('subject', null, ["class" => "search-input-text form-control", "data-column" => 1, "placeholder" => trans('labels.backend.emailtemplates.table.subject')]); ?>

                                <a class="reset-data" href="javascript:void(0)" data-column=1><i class="fa fa-times"></i></a>
                            </th>
                            <th>
                                <?php echo Form::select('status', [0 => "InActive", 1 => "Active"], null, ["class" => "search-input-select form-control", "data-column" => 2, "placeholder" => trans('labels.backend.emailtemplates.table.all')]); ?>

                            </th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div><!--table-responsive-->
        </div><!-- /.box-body -->
    </div><!--box-->

    <!--<div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(trans('history.backend.recent_history')); ?></h3>
            <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            </div><!-- /.box tools -->
        </div><!-- /.box-header -->
        <div class="box-body">
            
        </div><!-- /.box-body -->
    </div><!--box box-info-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after-scripts'); ?>
    
    <?php echo e(Html::script(mix('js/dataTable.js'))); ?>


    <script>
        $(function() {
            var dataTable = $('#emailtemplates-table').dataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '<?php echo e(route("admin.emailtemplates.get")); ?>',
                    type: 'post'
                },
                columns: [
                    {data: 'title', name: '<?php echo e(config('module.email_templates.table')); ?>.title'},
                    {data: 'subject', name: '<?php echo e(config('module.email_templates.table')); ?>.subject'},
                    {data: 'status', name: '<?php echo e(config('module.email_templates.table')); ?>.status'},
                    {data: 'created_at', name: '<?php echo e(config('module.email_templates.table')); ?>.created_at'},
                    {data: 'updated_at', name: '<?php echo e(config('module.email_templates.table')); ?>.updated_at'},
                    {data: 'actions', name: 'actions', searchable: false, sortable: false}
                ],
                order: [[3, "asc"]],
                searchDelay: 500,
                dom: 'lBfrtip',
                buttons: {
                    buttons: [
                        { extend: 'copy', className: 'copyButton',  exportOptions: {columns: [ 0, 1, 2, 3, 4 ]  }},
                        { extend: 'csv', className: 'csvButton',  exportOptions: {columns: [ 0, 1, 2, 3, 4 ]  }},
                        { extend: 'excel', className: 'excelButton',  exportOptions: {columns: [ 0, 1, 2, 3, 4 ]  }},
                        { extend: 'pdf', className: 'pdfButton',  exportOptions: {columns: [ 0, 1, 2, 3, 4 ]  }},
                        { extend: 'print', className: 'printButton',  exportOptions: {columns: [ 0, 1, 2, 3, 4 ]  }}
                    ]
                }
            });

            Backend.DataTableSearch.init(dataTable);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>