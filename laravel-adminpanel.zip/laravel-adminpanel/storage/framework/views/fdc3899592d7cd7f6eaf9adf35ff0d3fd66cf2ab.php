<?php echo e(Html::script("js/plugin/datatables/jquery.dataTables.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/dataTables.bootstrap.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/dataTables.buttons.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/buttons.flash.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/jszip.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/pdfmake.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/vfs_fonts.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/buttons.html5.min.js")); ?>

<?php echo e(Html::script("js/plugin/datatables/buttons.print.min.js")); ?>

<?php echo e(Html::style("css/plugin/datatables/buttons.dataTables.min.css")); ?>

<?php echo e(Html::style("css/plugin/datatables/jquery.dataTables.min.css")); ?>

